import { useState, useEffect, useCallback } from 'react'
import { motion } from 'framer-motion'
import {
  FileText,
  Download,
  Calendar,
  User,
  BookOpen,
  Sparkles,
  CheckCircle2,
  GraduationCap,
  ChevronRight
} from 'lucide-react'
import { Button } from '@/components/ui/button'

function AnimatedBackground() {
  const [particles] = useState(() =>
    Array.from({ length: 30 }, (_, i) => ({
      id: i,
      x: Math.random() * 100,
      y: Math.random() * 100,
      size: Math.random() * 4 + 1,
      duration: Math.random() * 20 + 15,
      delay: Math.random() * 10,
      opacity: Math.random() * 0.4 + 0.1
    }))
  )

  return (
    <div className="fixed inset-0 overflow-hidden pointer-events-none">
      <div
        className="absolute inset-0"
        style={{
          background:
            'radial-gradient(ellipse 80% 60% at 50% 0%, rgba(124, 58, 237, 0.12) 0%, transparent 60%), radial-gradient(ellipse 60% 50% at 80% 80%, rgba(99, 102, 241, 0.08) 0%, transparent 50%)'
        }}
      />
      {particles.map(p => (
        <motion.div
          key={p.id}
          className="absolute rounded-full bg-violet-400"
          style={{
            width: p.size,
            height: p.size,
            left: `${p.x}%`,
            top: `${p.y}%`,
            opacity: p.opacity
          }}
          animate={{
            y: [0, -30, 0],
            x: [0, Math.random() * 20 - 10, 0],
            opacity: [p.opacity, p.opacity * 2, p.opacity]
          }}
          transition={{
            duration: p.duration,
            delay: p.delay,
            repeat: Infinity,
            ease: 'easeInOut'
          }}
        />
      ))}
    </div>
  )
}

function FloatingBadge({ children, icon: Icon, delay = 0 }: { children: string; icon: React.ElementType; delay?: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.8 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ delay, duration: 0.5 }}
      className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 border border-white/10 backdrop-blur-sm"
    >
      <Icon className="w-4 h-4 text-violet-400" />
      <span className="text-sm text-white/80">{children}</span>
    </motion.div>
  )
}

function TaskItem({ number, delay }: { number: number; delay: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, x: -20 }}
      whileInView={{ opacity: 1, x: 0 }}
      viewport={{ once: true }}
      transition={{ delay, duration: 0.4 }}
      className="flex items-center gap-3 group"
    >
      <div className="w-8 h-8 rounded-lg bg-violet-500/10 border border-violet-500/20 flex items-center justify-center group-hover:bg-violet-500/20 transition-colors">
        <CheckCircle2 className="w-4 h-4 text-violet-400" />
      </div>
      <span className="text-white/70 group-hover:text-white/90 transition-colors">Задание {number}</span>
    </motion.div>
  )
}

export default function App() {
  const [scrollY, setScrollY] = useState(0)
  const [isHovering, setIsHovering] = useState(false)

  const handleScroll = useCallback(() => setScrollY(window.scrollY), [])

  useEffect(() => {
    window.addEventListener('scroll', handleScroll, { passive: true })
    return () => window.removeEventListener('scroll', handleScroll)
  }, [handleScroll])

  const handleDownload = () => {
    const link = document.createElement('a')
    link.href = '/Буравцов.pdf'
    link.download = 'Буравцов_Презентация_Цифровой_Куратор.pdf'
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
  }

  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white relative overflow-x-hidden">
      <AnimatedBackground />

      {/* Header */}
      <motion.header
        initial={{ y: -40, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.6 }}
        className="fixed top-0 left-0 right-0 z-50 flex items-center justify-between px-6 md:px-12 py-4 backdrop-blur-xl bg-[#0a0a0f]/60 border-b border-white/5"
      >
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-violet-600 flex items-center justify-center">
            <GraduationCap className="w-5 h-5 text-white" />
          </div>
          <span className="font-semibold text-white/90">Цифровой куратор</span>
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={handleDownload}
            className="text-white/60 hover:text-white hover:bg-white/10"
          >
            <Download className="w-4 h-4 mr-2" />
            Скачать
          </Button>
        </div>
      </motion.header>

      {/* Hero Section */}
      <section className="relative pt-32 pb-20 px-6 md:px-12 max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="text-center mb-12"
        >
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.5, type: 'spring', stiffness: 200 }}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-violet-500/10 border border-violet-500/20 mb-8"
          >
            <Sparkles className="w-4 h-4 text-violet-400" />
            <span className="text-sm text-violet-300">Квалификационный экзамен 2026</span>
          </motion.div>

          <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold tracking-tight mb-6 leading-tight">
            <span className="text-white">Презентация по</span>
            <br />
            <span
              className="bg-clip-text text-transparent"
              style={{
                backgroundImage: 'linear-gradient(135deg, #a78bfa 0%, #6366f1 50%, #818cf8 100%)'
              }}
            >
              цифровой грамотности
            </span>
          </h1>

          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.6 }}
            className="text-lg md:text-xl text-white/50 max-w-2xl mx-auto mb-10 leading-relaxed"
          >
            Алгоритм выполнения практического этапа квалификационного экзамена по специальности
            «Консультант в области развития цифровой грамотности (Цифровой куратор)»
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.8 }}
            className="flex flex-wrap justify-center gap-4 mb-12"
          >
            <FloatingBadge icon={User} delay={0.9}>
              Буравцов И.Ю.
            </FloatingBadge>
            <FloatingBadge icon={BookOpen} delay={1.0}>
              Группа 1-РМ9-9
            </FloatingBadge>
            <FloatingBadge icon={Calendar} delay={1.1}>
              Москва, 2026
            </FloatingBadge>
          </motion.div>

          {/* Main Download Button */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 1.0, type: 'spring', stiffness: 150 }}
          >
            <Button
              size="lg"
              onClick={handleDownload}
              onMouseEnter={() => setIsHovering(true)}
              onMouseLeave={() => setIsHovering(false)}
              className="relative px-10 py-7 text-lg font-semibold rounded-2xl overflow-hidden group"
              style={{
                background: 'linear-gradient(135deg, #7c3aed 0%, #6366f1 100%)'
              }}
            >
              <span className="relative z-10 flex items-center gap-3">
                <Download className="w-5 h-5" />
                Скачать презентацию
                <motion.span
                  animate={{ x: isHovering ? 4 : 0 }}
                  transition={{ duration: 0.2 }}
                >
                  <ChevronRight className="w-5 h-5" />
                </motion.span>
              </span>
              <motion.div
                className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity"
                style={{
                  background: 'linear-gradient(135deg, #8b5cf6 0%, #7c3aed 100%)'
                }}
              />
            </Button>
          </motion.div>

          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.2 }}
            className="mt-4 text-sm text-white/30"
          >
            PDF файл, 11 слайдов
          </motion.p>
        </motion.div>

        {/* File Preview Card */}
        <motion.div
          initial={{ opacity: 0, y: 60 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.2, duration: 0.8 }}
          style={{ y: scrollY * 0.05 }}
          className="relative max-w-lg mx-auto"
        >
          <div className="relative rounded-2xl overflow-hidden border border-white/10 bg-white/[0.02] backdrop-blur-sm shadow-2xl shadow-violet-500/5">
            <div className="flex items-center gap-2 px-4 py-3 border-b border-white/5 bg-white/[0.02]">
              <div className="flex gap-2">
                <div className="w-3 h-3 rounded-full bg-red-500/80" />
                <div className="w-3 h-3 rounded-full bg-yellow-500/80" />
                <div className="w-3 h-3 rounded-full bg-green-500/80" />
              </div>
              <span className="ml-4 text-xs text-white/30">Буравцов.pdf</span>
            </div>
            <div className="p-8 text-center">
              <motion.div
                animate={{ rotate: [0, -3, 3, 0] }}
                transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut' }}
                className="inline-block mb-6"
              >
                <FileText className="w-24 h-24 text-violet-400/80" strokeWidth={1} />
              </motion.div>
              <h3 className="text-xl font-semibold text-white/90 mb-2">Презентация</h3>
              <p className="text-sm text-white/40 mb-6">
                Алгоритм выполнения практического этапа квалификационного экзамена
              </p>
              <div className="flex items-center justify-center gap-6 text-xs text-white/30">
                <span className="flex items-center gap-1.5">
                  <FileText className="w-3.5 h-3.5" /> PDF
                </span>
                <span className="flex items-center gap-1.5">
                  <BookOpen className="w-3.5 h-3.5" /> 11 страниц
                </span>
              </div>
            </div>
          </div>

          {/* Decorative glow */}
          <div
            className="absolute -inset-4 rounded-3xl opacity-30 blur-2xl -z-10"
            style={{
              background: 'radial-gradient(circle, rgba(124, 58, 237, 0.3) 0%, transparent 70%)'
            }}
          />
        </motion.div>
      </section>

      {/* Content Section */}
      <section className="relative py-20 px-6 md:px-12 max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="grid md:grid-cols-2 gap-12"
        >
          {/* Info Card */}
          <div className="rounded-2xl border border-white/10 bg-white/[0.02] backdrop-blur-sm p-8">
            <h2 className="text-2xl font-bold text-white/90 mb-6 flex items-center gap-3">
              <BookOpen className="w-6 h-6 text-violet-400" />
              Содержание работы
            </h2>
            <div className="space-y-4">
              {[1, 2, 3, 4].map(n => (
                <TaskItem key={n} number={n} delay={n * 0.1} />
              ))}
              <TaskItem number={5} delay={0.5} />
            </div>
            <div className="mt-8 pt-6 border-t border-white/5">
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-lg bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center shrink-0">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                </div>
                <div>
                  <p className="text-white/80 font-medium">Вывод</p>
                  <p className="text-sm text-white/40 mt-1">
                    Все задания практического этапа успешно выполнены
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* About Card */}
          <div className="rounded-2xl border border-white/10 bg-white/[0.02] backdrop-blur-sm p-8">
            <h2 className="text-2xl font-bold text-white/90 mb-6 flex items-center gap-3">
              <GraduationCap className="w-6 h-6 text-violet-400" />
              О квалификации
            </h2>
            <p className="text-white/60 leading-relaxed mb-6">
              Данная презентация подготовлена в рамках квалификационного экзамена по ДУП.01
              «Практическая подготовка по технологии выполнения работ по должности служащего
              «Консультант в области развития цифровой грамотности (Цифровой куратор)».
            </p>
            <div className="space-y-4">
              <div className="flex items-center gap-4 p-4 rounded-xl bg-white/[0.03] border border-white/5">
                <div className="w-10 h-10 rounded-lg bg-violet-500/10 flex items-center justify-center">
                  <User className="w-5 h-5 text-violet-400" />
                </div>
                <div>
                  <p className="text-sm text-white/40">Студент</p>
                  <p className="text-white/80 font-medium">Буравцов И.Ю.</p>
                </div>
              </div>
              <div className="flex items-center gap-4 p-4 rounded-xl bg-white/[0.03] border border-white/5">
                <div className="w-10 h-10 rounded-lg bg-violet-500/10 flex items-center justify-center">
                  <BookOpen className="w-5 h-5 text-violet-400" />
                </div>
                <div>
                  <p className="text-sm text-white/40">Учебная группа</p>
                  <p className="text-white/80 font-medium">1-РМ9-9</p>
                </div>
              </div>
              <div className="flex items-center gap-4 p-4 rounded-xl bg-white/[0.03] border border-white/5">
                <div className="w-10 h-10 rounded-lg bg-violet-500/10 flex items-center justify-center">
                  <Calendar className="w-5 h-5 text-violet-400" />
                </div>
                <div>
                  <p className="text-sm text-white/40">Год защиты</p>
                  <p className="text-white/80 font-medium">2026</p>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </section>

      {/* Bottom CTA */}
      <section className="relative py-20 px-6 md:px-12 max-w-4xl mx-auto text-center">
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="rounded-3xl border border-white/10 bg-white/[0.02] backdrop-blur-sm p-12 relative overflow-hidden"
        >
          <div
            className="absolute inset-0 opacity-20"
            style={{
              background: 'radial-gradient(circle at 50% 0%, rgba(124, 58, 237, 0.3), transparent 60%)'
            }}
          />
          <div className="relative z-10">
            <h2 className="text-3xl md:text-4xl font-bold text-white/90 mb-4">
              Готовы ознакомиться?
            </h2>
            <p className="text-white/40 mb-8 max-w-lg mx-auto">
              Скачайте презентацию в формате PDF и изучите все выполненные задания
            </p>
            <Button
              size="lg"
              onClick={handleDownload}
              className="px-8 py-6 text-base font-semibold rounded-xl"
              style={{
                background: 'linear-gradient(135deg, #7c3aed 0%, #6366f1 100%)'
              }}
            >
              <Download className="w-5 h-5 mr-2" />
              Скачать PDF
            </Button>
          </div>
        </motion.div>
      </section>

      {/* Footer */}
      <footer className="relative py-8 px-6 border-t border-white/5 text-center">
        <p className="text-sm text-white/20">
          Буравцов И.Ю. &mdash; Цифровой куратор &mdash; 2026
        </p>
      </footer>
    </div>
  )
}
